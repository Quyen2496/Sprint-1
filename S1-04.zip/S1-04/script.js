const permissions={
 Admin:["dashboard","booking","customers","rooms","cleaning","pricing","accounts","permissions","tokens","migration"],
 LeTan:["dashboard","booking","customers","rooms","payments","history"],
 BuongPhong:["dashboard","cleaning","rooms"]
};
const menuItems=[
 ["dashboard","🏠","Tổng quan"],["booking","📅","Đặt phòng"],["customers","👥","Khách hàng"],
 ["rooms","🛏️","Phòng"],["cleaning","🧹","Phòng cần dọn"],["payments","💳","Thanh toán"],
 ["history","📋","Lịch sử"],["pricing","💰","Khai báo giá"],["accounts","👤","Tài khoản"],
 ["permissions","🛡️","Phân quyền"],["tokens","🔑","Refresh Token"],["migration","🗄️","Migration"]
];
const roles={Admin:{name:"Admin",email:"admin@gmail.com",avatar:"AD"},LeTan:{name:"Lễ tân",email:"letan@gmail.com",avatar:"LT"},BuongPhong:{name:"Buồng phòng",email:"buongphong@gmail.com",avatar:"BP"}};
let currentRole="LeTan";

function login(){
 currentRole=document.getElementById("loginRole").value;
 document.getElementById("loginPage").classList.add("hidden");
 document.getElementById("app").classList.remove("hidden");
 const u=roles[currentRole];
 document.getElementById("userName").textContent=u.name;
 document.getElementById("userRole").textContent=u.email;
 document.getElementById("avatar").textContent=u.avatar;
 document.getElementById("roleChip").textContent=u.name;
 renderMenu();openPage("dashboard");
 showToast("Đăng nhập thành công — "+u.name);
}
document.getElementById("loginBtn").onclick=login;
document.getElementById("logoutBtn").onclick=()=>{document.getElementById("app").classList.add("hidden");document.getElementById("loginPage").classList.remove("hidden")};

function renderMenu(){
 const allowed=permissions[currentRole];
 document.getElementById("menu").innerHTML=menuItems.map(([id,icon,label])=>{
   if(!allowed.includes(id)) return "";
   return `<button class="nav" data-page="${id}" onclick="openPage('${id}')"><span>${icon}</span><span>${label}</span></button>`;
 }).join("");
}
function openPage(page){
 if(!permissions[currentRole].includes(page)){showForbidden();return}
 document.querySelectorAll(".nav").forEach(x=>x.classList.toggle("active",x.dataset.page===page));
 const titles={dashboard:["Tổng quan","Tổng quan quyền truy cập của vai trò hiện tại."],booking:["Đặt phòng","Quản lý đặt phòng theo quyền của Lễ tân."],customers:["Khách hàng","Thông tin khách hàng."],rooms:["Phòng","Danh sách phòng."],cleaning:["Phòng cần dọn","Danh sách công việc dành cho Buồng phòng."],payments:["Thanh toán","Xử lý thanh toán."],history:["Lịch sử","Lịch sử thao tác và giao dịch."],pricing:["Khai báo giá","Cấu hình bảng giá — chỉ vai trò được cấp quyền."],accounts:["Account Database","Thiết kế bảng Account và trạng thái tài khoản."],permissions:["Permission Matrix","Ma trận phân quyền được khai báo tập trung."],tokens:["Refresh Token","Các token được lưu trong Database."],migration:["Migration","Trạng thái migration Database."]};
 document.getElementById("pageTitle").textContent=titles[page][0];document.getElementById("pageSub").textContent=titles[page][1];
 document.getElementById("content").innerHTML=views[page]();
}
function showForbidden(){document.getElementById("forbidden").classList.remove("hidden")}
function closeForbidden(){document.getElementById("forbidden").classList.add("hidden")}
function showToast(t){const x=document.getElementById("toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2200)}

const views={
dashboard:()=>`<div class="grid4"><div class="stat"><span>Vai trò hiện tại</span><strong>${roles[currentRole].name}</strong></div><div class="stat"><span>Quyền được cấp</span><strong>${permissions[currentRole].length}</strong></div><div class="stat"><span>Menu hiển thị</span><strong>${permissions[currentRole].length}</strong></div><div class="stat"><span>Database</span><strong class="ok">Online</strong></div></div><div class="panel section"><div class="panel-head"><div><h2>Kiểm tra phân quyền</h2><p>Menu được sinh từ Permission Matrix, không cấu hình riêng từng màn hình.</p></div><span class="migration">✓ Authorization ON</span></div><div class="info-list">${permissions[currentRole].map(p=>`<div class="info-row"><span>${menuItems.find(x=>x[0]===p)?.[2]||p}</span><b class="ok">Được phép</b></div>`).join("")}</div></div>`,
booking:()=>simple("📅","Đặt phòng","Lễ tân có quyền quản lý đặt phòng."),
customers:()=>simple("👥","Khách hàng","Lễ tân có quyền xem và quản lý thông tin khách hàng."),
rooms:()=>simple("🛏️","Danh sách phòng","Hiển thị tình trạng phòng theo quyền được cấp."),
cleaning:()=>simple("🧹","Danh sách phòng cần dọn","Vai trò Buồng phòng chỉ thấy các phòng cần dọn và trạng thái công việc."),
payments:()=>simple("💳","Thanh toán","Lễ tân có thể thực hiện và tra cứu thanh toán."),
history:()=>simple("📋","Lịch sử","Theo dõi các hoạt động được phép."),
pricing:()=>simple("💰","Khai báo giá","Màn hình cấu hình giá. Vai trò không có quyền sẽ nhận 403 nếu gọi route trực tiếp."),
accounts:()=>`<div class="panel"><div class="panel-head"><div><h2>Account</h2><p>Thiết kế theo yêu cầu Database.</p></div><span class="migration">✓ Migration Applied</span></div><div class="table-wrap"><table><thead><tr><th>id</th><th>email</th><th>passwordHash</th><th>failedLoginAttempts</th><th>lastFailedLoginAt</th><th>lockedAt</th><th>role</th></tr></thead><tbody><tr><td>1</td><td><b>admin@gmail.com</b></td><td class="hash">$2b$12$••••••••••••••</td><td>0</td><td>—</td><td>—</td><td><span class="badge admin">Admin</span></td></tr><tr><td>2</td><td><b>letan@gmail.com</b></td><td class="hash">$2b$12$••••••••••••••</td><td>0</td><td>—</td><td>—</td><td><span class="badge reception">Lễ tân</span></td></tr><tr><td>3</td><td><b>buongphong@gmail.com</b></td><td class="hash">$2b$12$••••••••••••••</td><td>0</td><td>—</td><td>—</td><td><span class="badge house">Buồng phòng</span></td></tr></tbody></table></div></div>`,
permissions:()=>`<div class="panel"><div class="panel-head"><div><h2>Permission Matrix</h2><p>Khai báo tập trung một nơi duy nhất.</p></div><span class="migration">3 Roles</span></div><div class="table-wrap"><table class="matrix"><thead><tr><th>Chức năng</th><th>Admin</th><th>Lễ tân</th><th>Buồng phòng</th></tr></thead><tbody>${menuItems.map(x=>`<tr><td>${x[2]}</td><td>${permissions.Admin.includes(x[0])?'<span class="yes">✓</span>':'<span class="no">—</span>'}</td><td>${permissions.LeTan.includes(x[0])?'<span class="yes">✓</span>':'<span class="no">—</span>'}</td><td>${permissions.BuongPhong.includes(x[0])?'<span class="yes">✓</span>':'<span class="no">—</span>'}</td></tr>`).join("")}</tbody></table></div></div>`,
tokens:()=>`<div class="cards2"><div class="panel"><div class="panel-head"><div><h2>RefreshToken</h2><p>Thiết kế khi hệ thống lưu token trong DB.</p></div></div><div class="info-list"><div class="info-row"><span>id</span><b>1</b></div><div class="info-row"><span>token</span><b class="hash">eyJhbGciOi••••</b></div><div class="info-row"><span>expiresAt</span><b>24/09/2026</b></div><div class="info-row"><span>revokedAt</span><b>NULL</b></div><div class="info-row"><span>accountId</span><b>1</b></div></div></div><div class="panel"><div class="panel-head"><div><h2>Account → RefreshToken</h2><p>Quan hệ 1 - N.</p></div></div><div class="info-list"><div class="info-row"><span>Account</span><b>1</b></div><div class="info-row"><span>RefreshToken</span><b>N</b></div><div class="info-row"><span>Foreign Key</span><b>accountId</b></div></div></div></div>`,
migration:()=>`<div class="cards2"><div class="panel"><div class="panel-head"><div><h2>Migration</h2><p>Entity Framework Core.</p></div><span class="migration">✓ Applied</span></div><div class="info-list"><div class="info-row"><span>InitialCreate</span><b class="ok">Applied</b></div><div class="info-row"><span>Accounts table</span><b class="ok">Created</b></div><div class="info-row"><span>RefreshTokens table</span><b class="ok">Created</b></div><div class="info-row"><span>Unique Email Index</span><b class="ok">Created</b></div></div></div><div class="panel"><div class="panel-head"><div><h2>Security</h2><p>Thông tin cần có trong Database.</p></div></div><div class="info-list"><div class="info-row"><span>Password storage</span><b>BCrypt Hash</b></div><div class="info-row"><span>Failed attempts</span><b>Tracked</b></div><div class="info-row"><span>Account lock</span><b>Supported</b></div><div class="info-row"><span>Refresh token</span><b>DB stored</b></div></div></div></div>`
};
function simple(icon,title,text){return `<div class="panel"><div class="panel-head"><div><h2>${icon} ${title}</h2><p>${text}</p></div></div><div class="info-list"><div class="info-row"><span>Quyền hiện tại</span><b class="ok">Được phép</b></div><div class="info-row"><span>Role</span><b>${roles[currentRole].name}</b></div></div></div>`}
