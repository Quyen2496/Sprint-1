using App.Modules.Authentication.Services;
using Microsoft.Extensions.DependencyInjection;

namespace App.Modules.Authentication
{
    public static class AuthenticationModuleExtensions
    {
        public static IServiceCollection AddAccountLockModule(this IServiceCollection services)
        {
            services.AddScoped<IAuthModuleService, AuthModuleService>();
            return services;
        }
    }
}
