namespace App.Modules.Authentication.Models
{
    public interface IAccountLockInfo
    {
        int FailedLoginAttempts { get; set; }
        DateTime? LastFailedLoginAt { get; set; }
        DateTime? LockedAt { get; set; }
    }

    public class LoginResult
    {
        public bool IsSuccess { get; set; }
        public bool IsLocked { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}
