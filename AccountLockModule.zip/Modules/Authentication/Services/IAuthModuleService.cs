using System;
using App.Modules.Authentication.Models;

namespace App.Modules.Authentication.Services
{
    public interface IAuthModuleService
    {
        /// <summary>
        /// Kiểm tra tài khoản có đang bị khóa hay không. Tự động mở khóa nếu hết 30 phút.
        /// </summary>
        bool IsLockedOut(IAccountLockInfo user);

        /// <summary>
        /// Xử lý khi người dùng nhập sai mật khẩu (Đếm 5 lần trong 15 phút, khóa 30 phút).
        /// </summary>
        void HandleFailedLogin(IAccountLockInfo user);

        /// <summary>
        /// Xử lý khi đăng nhập thành công (Reset các bộ đếm).
        /// </summary>
        void HandleSuccessfulLogin(IAccountLockInfo user);
    }
}
