using System;
using App.Modules.Authentication.Models;

namespace App.Modules.Authentication.Services
{
    public class AuthModuleService : IAuthModuleService
    {
        private const int MAX_FAILED_ATTEMPTS = 5;
        private const int WINDOW_MINUTES = 15;
        private const int LOCK_MINUTES = 30;

        public bool IsLockedOut(IAccountLockInfo user)
        {
            if (!user.LockedAt.HasValue) 
                return false;

            // Kiểm tra xem đã qua 30 phút chưa
            if (DateTime.UtcNow >= user.LockedAt.Value.AddMinutes(LOCK_MINUTES))
            {
                // Đã hết 30 phút -> Tự động mở khóa
                user.LockedAt = null;
                user.FailedLoginAttempts = 0;
                user.LastFailedLoginAt = null;
                return false;
            }

            return true; // Vẫn đang trong thời gian bị khóa 30 phút
        }

        public void HandleFailedLogin(IAccountLockInfo user)
        {
            var now = DateTime.UtcNow;

            // Nếu lần nhập sai trước đó vượt quá 15 phút -> Đếm lại từ 1
            if (user.LastFailedLoginAt.HasValue && 
                now > user.LastFailedLoginAt.Value.AddMinutes(WINDOW_MINUTES))
            {
                user.FailedLoginAttempts = 1;
            }
            else
            {
                user.FailedLoginAttempts++;
            }

            user.LastFailedLoginAt = now;

            // Đủ 5 lần sai -> Khóa 30 phút
            if (user.FailedLoginAttempts >= MAX_FAILED_ATTEMPTS)
            {
                user.LockedAt = now;
            }
        }

        public void HandleSuccessfulLogin(IAccountLockInfo user)
        {
            // Reset bộ đếm về 0 khi đăng nhập thành công
            user.FailedLoginAttempts = 0;
            user.LastFailedLoginAt = null;
            user.LockedAt = null;
        }
    }
}
