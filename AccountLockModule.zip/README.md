# Account Lock Module (ASP.NET Core)

Module độc lập xử lý khóa tài khoản tự động khi đăng nhập sai quá nhiều lần.

## Tính năng
- Đếm số lần đăng nhập sai (`FailedLoginAttempts`).
- Lưu thời gian nhập sai gần nhất (`LastFailedLoginAt`) và thời gian bị khóa (`LockedAt`).
- Sai 5 lần liên tiếp trong cửa sổ 15 phút -> Tự động khóa 30 phút.
- Tự động mở khóa sau 30 phút khi người dùng truy cập lại.
- Tự động reset bộ đếm khi đăng nhập thành công.

## Hướng dẫn tích hợp cho Team

### 1. Kế thừa Interface vào Entity User của dự án
```csharp
using App.Modules.Authentication.Models;

public class User : IAccountLockInfo
{
    public int Id { get; set; }
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;

    // Các thuộc tính bắt buộc của Module Khóa Tài Khoản
    public int FailedLoginAttempts { get; set; } = 0;
    public DateTime? LastFailedLoginAt { get; set; }
    public DateTime? LockedAt { get; set; }
}
```

### 2. Đăng ký Module trong `Program.cs`
```csharp
using App.Modules.Authentication;

var builder = WebApplication.CreateBuilder(args);

// Đăng ký Module Khóa Tài Khoản
builder.Services.AddAccountLockModule();
```

### 3. Sử dụng trong AuthController / Login Logic
```csharp
[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthModuleService _authModule;
    private readonly ApplicationDbContext _context;

    public AuthController(IAuthModuleService authModule, ApplicationDbContext context)
    {
        _authModule = authModule;
        _context = context;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest request)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == request.Email);
        if (user == null) return BadRequest("Email hoặc mật khẩu không chính xác.");

        // 1. Kiểm tra tài khoản có đang bị khóa không
        if (_authModule.IsLockedOut(user))
        {
            await _context.SaveChangesAsync(); // Lưu lại nếu tài khoản vừa được tự động mở khóa
            return StatusCode(403, "Tài khoản đang bị khóa do nhập sai 5 lần. Thử lại sau 30 phút.");
        }

        // 2. Kiểm tra mật khẩu
        bool isPasswordValid = VerifyPassword(request.Password, user.PasswordHash);

        if (!isPasswordValid)
        {
            // Xử lý đếm lần sai / Khóa tài khoản
            _authModule.HandleFailedLogin(user);
            await _context.SaveChangesAsync();
            
            return BadRequest("Email hoặc mật khẩu không chính xác.");
        }

        // 3. Đăng nhập thành công -> Reset bộ đếm
        _authModule.HandleSuccessfulLogin(user);
        await _context.SaveChangesAsync();

        return Ok("Đăng nhập thành công!");
    }
}
```
