const bcrypt = require('bcrypt');
const saltRounds = 10;

// 1. Hàm băm mật khẩu khi tạo tài khoản
const hashPassword = async (plainPassword) => {
    try {
        const hashedPassword = await bcrypt.hash(plainPassword, saltRounds);
        return hashedPassword;
    } catch (error) {
        throw new Error('Lỗi khi băm mật khẩu: ' + error.message);
    }
};

// 2. Hàm kiểm tra mật khẩu nhập vào với BCrypt hash (dùng khi đăng nhập)
const comparePassword = async (plainPassword, hashedPassword) => {
    try {
        const isMatch = await bcrypt.compare(plainPassword, hashedPassword);
        return isMatch;
    } catch (error) {
        throw new Error('Lỗi khi kiểm tra mật khẩu: ' + error.message);
    }
};

module.exports = { hashPassword, comparePassword };