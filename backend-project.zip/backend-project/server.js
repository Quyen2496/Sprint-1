const express = require('express');
const mongoose = require('mongoose');
const { register, login } = require('./controllers/authController');

const app = express();
app.use(express.json());

// Kết nối MongoDB
mongoose.connect('mongodb://localhost:27017/quanly_nhom', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('Kết nối Database thành công!');
}).catch(err => console.log('Lỗi kết nối DB:', err));

// Routes API
app.post('/api/register', register);
app.post('/api/login', login);

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server đang chạy tại http://localhost:${PORT}`);
});